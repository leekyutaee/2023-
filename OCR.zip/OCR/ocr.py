from PIL import Image, ImageFilter
from pytesseract import image_to_string
import pytesseract
import cv2
import os
import tkinter.messagebox
import re
import tkinter as tk
from tkinter import filedialog
from PIL import Image, ImageTk, ExifTags

class PhotoViewerApp:
    def __init__(self, master):
        self.master = master
        self.master.title("병용주의약물 비교기")
        self.master.geometry("1200x800")

        self.image_label1 = tk.Label(self.master)
        self.image_label1.place(x=200, y=70)

        self.image_label2 = tk.Label(self.master)
        self.image_label2.place(x=700, y=70)

        self.file_path = None  # 인스턴스 변수로 file_path를 초기화

        menu_bar = tk.Menu(self.master)
        self.master.config(menu=menu_bar)

        file_menu = tk.Menu(menu_bar, tearoff=0)
        menu_bar.add_cascade(label="File", menu=file_menu)
        file_menu.add_command(label="Open Image 1", command=lambda: self.open_image(self.image_label1))
        file_menu.add_command(label="Open Image 2", command=lambda: self.open_image2(self.image_label2))

        self.show_button = tk.Button(self.master, text="비교 시작", command=self.compare, width=15, height=2)
        self.show_button.place(x=550, y=400)

    def compare(self):
        print("비교 버튼 눌림")

        # OCR로 추출한 모든 텍스트 파일을 GUI에 표시
        file_paths = [
            "sample_output_image1_1_dname.txt",
            "sample_output_image1_2_dname.txt",
            "sample_output_image1_3_dname.txt",
            "sample_output_image1_4_dname.txt",
            "sample_output_image2_1_dname.txt",
            "sample_output_image2_2_dname.txt",
            "sample_output_image2_3_dname.txt",
            "sample_output_image2_4_dname.txt",
        ]

        text_content = ""
        drug_names_array = []
        for file_path in file_paths:
            try:
                # 파일 이름에서 위치와 처방전 번호 추출
                match = re.search(r'image(\d+)_(\d+)_dname.txt', file_path)
                if match:
                    prescription_number = match.group(1)
                    drug_number = match.group(2)
                else:
                    prescription_number = "Unknown"
                    drug_number = "Unknown"

                with open(file_path, "r") as file:
                    drug_name = file.readline().strip()  # 파일에서 첫 줄의 약물 이름 읽어오기
                    drug_names_array.append(drug_name)  # 배열에 약물 이름 추가

                    text_content += f"{prescription_number}번째 처방전의 {drug_number}번째 약물:\n{drug_name}\n\n"
            except FileNotFoundError:
                text_content += f"File {file_path} not found\n\n"

        self.display_text_content(text_content)
        print("약물 이름 배열:", drug_names_array)

        if '멜로덱스캡슬' in drug_names_array and '케톨락주' in drug_names_array:
        # 특정 텍스트 띄우기
            self.display_special_text("! 멜로덱스캡슬과 케톨락주를 함께 복용할 경우 중증 위장관계 이상반응 발생할수 있습니다 병용에 주의가 필요합니다. !")
        if '클래마신정' in drug_names_array and '페리돔정' in drug_names_array:
        # 특정 텍스트 띄우기
            self.display_special_text1("! 클래마신정과 페리돔정을 함께 복용하면 QTC 간격이 늘어나 심각한 위험이 있습니다. 두 약을 함께 복용하지 마세요. !")

    def display_special_text(self, text):
        special_label = tk.Label(self.master, text=text, font=("Arial", 12), fg="red")
        special_label.place(x=200, y=600)  # 특정 위치에 텍스트를 표시하도록 조정하세요.
    def display_special_text1(self, text):
        special_label = tk.Label(self.master, text=text, font=("Arial", 12), fg="red")
        special_label.place(x=200, y=700)  # 특정 위치에 텍스트를 표시하도록 조정하세요.

    def display_text_content(self, content):
    # 새로운 창에 텍스트를 표시하는 방식
        text_window = tk.Toplevel(self.master)
        text_window.title("OCR 추출된 텍스트")
        text_window.geometry("200x500+200+200")  # 창의 크기와 위치를 조정합니다. (너비x높이+x좌표+y좌표)
        
        text_label = tk.Label(text_window, text=content, wraplength=580, justify="left")
        text_label.pack(padx=10, pady=10)


    
    def open_image(self, image_label):
        self.file_path = filedialog.askopenfilename(filetypes=[("Image files", "*.png;*.jpg;*.jpeg;*.gif;*.bmp")])

        print("Selected File:", self.file_path)  # 디버깅을 위한 출력문 추가

        if self.file_path:
            original_image = Image.open(self.file_path)

            for orientation in ExifTags.TAGS.keys():
                if ExifTags.TAGS[orientation] == 'Orientation':
                    break
            try:
                exif = dict(original_image._getexif().items())
                if exif[orientation] == 3:
                    original_image = original_image.rotate(180, expand=True)
                elif exif[orientation] == 6:
                    original_image = original_image.rotate(270, expand=True)
                elif exif[orientation] == 8:
                    original_image = original_image.rotate(90, expand=True)
            except (AttributeError, KeyError, IndexError):
                pass

            original_image = original_image.rotate(-90, expand=True)  
            target_size = (300, 420)
            resized_image = original_image.resize(target_size, Image.LANCZOS)

            photo = ImageTk.PhotoImage(resized_image)
            
            image_label.config(image=photo)
            image_label.image = photo

            self.process_image()

    def open_image2(self, image_label):
        self.file_path = filedialog.askopenfilename(filetypes=[("Image files", "*.png;*.jpg;*.jpeg;*.gif;*.bmp")])

        print("Selected File:", self.file_path)  # 디버깅을 위한 출력문 추가

        if self.file_path:
            original_image = Image.open(self.file_path)

            for orientation in ExifTags.TAGS.keys():
                if ExifTags.TAGS[orientation] == 'Orientation':
                    break
            try:
                exif = dict(original_image._getexif().items())
                if exif[orientation] == 3:
                    original_image = original_image.rotate(180, expand=True)
                elif exif[orientation] == 6:
                    original_image = original_image.rotate(270, expand=True)
                elif exif[orientation] == 8:
                    original_image = original_image.rotate(90, expand=True)
            except (AttributeError, KeyError, IndexError):
                pass


            original_image = original_image.rotate(-90, expand=True)  
            target_size = (300, 420)
            resized_image = original_image.resize(target_size, Image.LANCZOS)

            photo = ImageTk.PhotoImage(resized_image)

            image_label.config(image=photo)
            image_label.image = photo

            self.process_image2()
            
    def process_image(self):
        if self.file_path:
            output_paths_and_coords = {
  
            "output_image1_1_dname.jpg": (1450, 2345, 1550, 2620), #약 1
          
            "output_image1_2_dname.jpg": (1550, 2470, 1650, 2625), #약 2
        
            "output_image1_3_dname.jpg": (1650, 2262, 1720, 2488), #약 3 세번째걸 늘리면 아래로 더 보임
           
            "output_image1_4_dname.jpg": (1750, 2359, 1850, 2630), #약 4
           
        }


            blur_strengths = {
               
                "output_image1_1_dname.jpg": 1.5, #약 1
              
                "output_image1_2_dname.jpg": 1.5, #약 2
            
                "output_image1_3_dname.jpg": 1.5, #약 3 세번째걸 늘리면 아래로 더 보임
             
                "output_image1_4_dname.jpg": 1.5, #약 4
            
            }

            border_sizes = {
          
                "output_image1_1_dname.jpg": 3, #약 1
          
                "output_image1_2_dname.jpg": 0, #약 2
              
                "output_image1_3_dname.jpg": 3, #약 3 세번째걸 늘리면 아래로 더 보임
              
                "output_image1_4_dname.jpg": 3, #약 4
              
        }

            extract_and_rotate_images(self.file_path, output_paths_and_coords, blur_strengths, border_sizes)

    def process_image2(self):
        if self.file_path:
            output_paths_and_coords = {
          
            "output_image2_1_dname.jpg": (1450, 2000, 1550, 2228), #약 1
           
            "output_image2_2_dname.jpg": (1555, 1943, 1610, 2233), #약 2 첫번째걸 늘리면 위에가 더잘림
           
            "output_image2_3_dname.jpg": (1640, 2002, 1710, 2258), #약 3 세번째걸 늘리면 아래로 더 보임
            
            "output_image2_4_dname.jpg": (1730, 2025, 1800, 2230), #약 4
           
        }


            blur_strengths = {
               
                "output_image2_1_dname.jpg": 1.5, #약 1
             
                "output_image2_2_dname.jpg": 2.2, #약 2
             
                "output_image2_3_dname.jpg": 1.5, #약 3 세번째걸 늘리면 아래로 더 보임
                
                "output_image2_4_dname.jpg": 2.5, #약 4
                
            }

            border_sizes = {
        
                "output_image2_1_dname.jpg": 3, #약 1
                
                "output_image2_2_dname.jpg": 3, #약 2
                
                "output_image2_3_dname.jpg": 3, #약 3 세번째걸 늘리면 아래로 더 보임
                
                "output_image2_4_dname.jpg": 3, #약 4
                
        }

            extract_and_rotate_images(self.file_path, output_paths_and_coords, blur_strengths, border_sizes)

def apply_blur(image, radius):
    blurred_image = image.filter(ImageFilter.GaussianBlur(radius))
    return blurred_image

def add_border(image, border_size):
    width, height = image.size
    new_width = width + 2 * border_size
    new_height = height + 2 * border_size
    
    new_image = Image.new("RGB", (new_width, new_height), (255, 255, 255))  # 흰색 배경
    new_image.paste(image, (border_size, border_size))
    
    return new_image

def extract_and_rotate_images(input_path, output_paths_and_coords, blur_strengths, border_sizes):
    image = Image.open(input_path)

    for output_path, (left, upper, right, lower) in output_paths_and_coords.items():
        cropped_image = image.crop((left, upper, right, lower))

        blur_radius = blur_strengths.get(output_path, 1.5)
        blurred_image = apply_blur(cropped_image, radius=blur_radius)

        border_size = border_sizes.get(output_path, 3)
        bordered_image = add_border(blurred_image, border_size=border_size)

        rotated_image = bordered_image.rotate(-90, expand=True)

        rotated_image.save(output_path)

        text = image_to_string(rotated_image, lang="kor")
        with open(f"sample_{output_path.split('.')[0]}.txt", "w") as f:
            f.write(text)

    print("이미지 편집, 회전, 텍스트 추출 및 저장이 완료되었습니다.")

if __name__ == "__main__":
    root = tk.Tk()
    app = PhotoViewerApp(root)
    root.mainloop()

    